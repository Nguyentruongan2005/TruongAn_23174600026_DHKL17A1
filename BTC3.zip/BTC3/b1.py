import numpy as np
#Lấy phiên bản Numpy
print("Phiên bản Numpy:", np.__version__)
#Hiển thị cấu hình xây dựng Numpy
np.show_config()